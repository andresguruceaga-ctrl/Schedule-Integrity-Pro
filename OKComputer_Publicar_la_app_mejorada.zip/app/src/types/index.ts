// Tipos para los criterios configurables de verificación de cronogramas

export interface CriterionThreshold {
  warning: number;
  critical: number;
}

export interface CriterionConfig {
  id: string;
  name: string;
  description: string;
  category: string;
  enabled: boolean;
  weight: number;
  threshold: CriterionThreshold;
}

export interface CategoryConfig {
  id: string;
  name: string;
  description: string;
  weight: number;
  enabled: boolean;
  criteria: CriterionConfig[];
}

export interface AnalysisResult {
  criterionId: string;
  score: number;
  status: 'ok' | 'warning' | 'critical';
  message: string;
  details?: string[];
  count?: number;
}

export interface CategoryResult {
  categoryId: string;
  score: number;
  results: AnalysisResult[];
}

export interface ScheduleAnalysis {
  id: string;
  name: string;
  date: Date;
  overallScore: number;
  status: 'excellent' | 'good' | 'fair' | 'poor';
  totalActivities: number;
  totalRelationships: number;
  criticalActivities: number;
  activitiesWithIssues: number;
  categoryResults: CategoryResult[];
}

export interface ScheduleData {
  activities: Activity[];
  relationships: Relationship[];
  calendars: Calendar[];
}

export interface Activity {
  id: string;
  name: string;
  duration: number;
  startDate: Date;
  endDate: Date;
  calendarId: string;
  wbsCode: string;
  isCritical: boolean;
  totalFloat: number;
  percentComplete: number;
  constraintType?: 'start' | 'finish' | 'none';
  constraintDate?: Date;
}

export interface Relationship {
  id: string;
  predecessor: string;
  successor: string;
  type: 'FS' | 'SS' | 'FF' | 'SF';
  lag: number;
}

export interface Calendar {
  id: string;
  name: string;
  workDays: number[];
  hoursPerDay: number;
}

export interface UserConfig {
  categories: CategoryConfig[];
  globalThresholds: {
    excellent: number;
    good: number;
    fair: number;
  };
}
